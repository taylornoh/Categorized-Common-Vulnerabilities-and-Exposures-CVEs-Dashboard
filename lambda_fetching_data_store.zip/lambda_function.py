import json
import requests
import boto3
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "*"
        }
    ]
}
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cpsc454-project')

def lambda_handler(event, context):
    webpage_url = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"

    response = requests.get(webpage_url)
    response.raise_for_status()
    data = response.json()
    

    company_count = {}

    for project in data.get("vulnerabilities", []):
        company = project["vendorProject"]
        if company not in company_count:
            company_count[company] = 0
        company_count[company] += 1

    for company, count in company_count.items():
        table.put_item(Item={
            'company': company,
            'total_vulnerabilities': count
        })
      
    return {
        'statusCode': 200,
        'body': json.dumps('Data processed and saved to DynamoDB!')
    }